export default {
    openGraph: {
      type: 'website',
      locale: 'en_IE',
      url: 'https://fang-zhang.github.io',
      site_name: 'Fang Zhang',
    },
    twitter: {
        handle: '@WalterFangZhang',
        site: '@WalterFangZhang',
        cardType: 'summary_large_image',
    }
  };