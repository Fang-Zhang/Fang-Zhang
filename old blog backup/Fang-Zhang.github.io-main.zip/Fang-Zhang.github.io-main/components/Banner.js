export default function Banner() {
  return (
    // <header className="py-5 bg-light border-bottom mb-4">
    //   <div className="container">
    //     <div className="text-center my-5">
    //       <h1 className="fw-bolder">Write down the memories of my life</h1>
    //       <p className="lead mb-0">
    //         Boost the Web3.0 entrepreneurs through full-stack technology.
    //       </p>
    //     </div>
    //   </div>
    // </header>
    <header/>
  );
}
