const SITE_URL = 'https://fang-zhang.github.io/'

export default SITE_URL