# Note to self

- Use `.not-prose` to avoid prose styles.
