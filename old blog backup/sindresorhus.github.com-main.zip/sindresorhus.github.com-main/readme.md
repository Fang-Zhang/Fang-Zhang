# [sindresorhus.com](https://sindresorhus.com)

> Personal website of Sindre Sorhus

*The website targets the latest version of Chrome, Safari, and Firefox.*
