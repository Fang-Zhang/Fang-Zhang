---
title: Blear
subtitle: Transform photos into blurry wallpapers
date: 2015-06-09
platforms:
  - iOS
repoUrl: https://github.com/sindresorhus/blear
appStoreId: 994182280
---

Blear lets you easily transform your own photos or the bundled ones into stunning blurry wallpapers for your device. Make your Home/Lock screen shine!
