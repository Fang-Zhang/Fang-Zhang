---
title: Actions
subtitle: Additional actions for the Shortcuts app
date: 2021-10-28
platforms:
  - macOS
  - iOS
repoUrl: https://github.com/sindresorhus/Actions
appStoreId: 1586435171
links:
  'Older Versions': https://github.com/sindresorhus/Actions#download
---

The app provides lots of powerful extra actions for the Shortcuts app on macOS and iOS. These actions make it significantly easier to create shortcuts.
