---
title: Kap
subtitle: Record your screen
date: 2018-02-01
platforms:
  - macOS
repoUrl: https://github.com/wulkano/kap
showSupportLink: false
---

An open-source macOS app I'm working on with my friends. It lets you quickly record your screen and then export it to various formats and services. The app supports plugins, trimming, window recording, and much more.
