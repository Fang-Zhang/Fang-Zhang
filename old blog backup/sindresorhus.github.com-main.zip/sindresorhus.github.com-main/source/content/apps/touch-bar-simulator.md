---
title: Touch Bar Simulator
subtitle: Use the Touch Bar on any Mac
date: 2017-04-16
platforms:
  - macOS
repoUrl: https://github.com/sindresorhus/touch-bar-simulator
---

Launch the Touch Bar simulator from anywhere without needing to have Xcode installed, whereas Apple requires you to launch it from inside Xcode. It also comes with a handy transparency slider, a screenshot button, and a service to toggle the Touch Bar in the Services menu or with a keyboard shortcut. (Open source)
