---
title: Plug
subtitle: Discover & listen to music from Hype Machine
date: 2021-01-16
platforms:
  - macOS
repoUrl: https://github.com/wulkano/Plug
appStoreId: 1514182074
links:
  'Older Versions': https://github.com/wulkano/Plug#download
showSupportLink: false
---

Plug is an open source macOS app I'm working on with my friends. Hype Machine is a popular music blog aggregator.
