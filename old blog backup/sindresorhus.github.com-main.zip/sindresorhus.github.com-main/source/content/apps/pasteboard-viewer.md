---
title: Pasteboard Viewer
subtitle: Inspect the system pasteboards
date: 2020-02-18
platforms:
  - macOS
repoUrl: https://github.com/sindresorhus/Pasteboard-Viewer
appStoreId: 1499215709
links:
  'Older Versions': https://github.com/sindresorhus/Pasteboard-Viewer#download
---
