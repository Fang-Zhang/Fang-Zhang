---
title: Caprine
subtitle: Elegant Facebook Messenger desktop app
date: 2015-09-16
platforms:
  - macOS
  - Linux
  - Windows
repoUrl: https://github.com/sindresorhus/caprine
---

Caprine is an open-source, cross-platform, and privacy-focused Facebook Messenger desktop app.
